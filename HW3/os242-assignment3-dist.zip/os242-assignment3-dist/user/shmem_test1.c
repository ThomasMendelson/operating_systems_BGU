#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
    int parentPid = getpid();
    int childPid;
    char* sharedMem;
    char* pointer = malloc(100*sizeof(char));
    if ((childPid = fork()) == 0){
        childPid = getpid();
        sleep(2); //wait for parent to finish the syscall
        //printf("child is printing value before map: %s\n" , pointer);
        sharedMem = map_shared_pages(parentPid, childPid , pointer , 100);
        printf("child printing: %s\n" , sharedMem);
    }
    else{
        strcpy (pointer , "Hello Child");
        //printf("parent after writing 'Hello World' to memory\n");
        wait(0);
    }
    free(pointer);
    exit(0);
}