#include "kernel/types.h"
#include "user/user.h"
#include "kernel/spinlock.h"
#include "kernel/sleeplock.h"
#include "kernel/fs.h"
#include "kernel/file.h"
#include "kernel/fcntl.h"

#include "kernel/crypto.h"

int main(void) {
  struct crypto_op* reqOp;
  uint64 sizeOfData;
  uint64 key_size;
  uint64 data_size;
  uchar* key;
  uchar* data;
  if(open("console", O_RDWR) < 0){
    mknod("console", CONSOLE, 0);
    open("console", O_RDWR);
  }
  dup(0);  // stdout
  dup(0);  // stderr

  printf("crypto_srv: starting\n");
  if (getpid() != 2) exit(1); //error 1 indicates that the server exit because pid was not 2.
  while(1){
    if (take_shared_memory_request((void*)&reqOp , &sizeOfData)) continue;
    if ((reqOp->state != CRYPTO_OP_STATE_INIT) || ((reqOp->type != CRYPTO_OP_TYPE_ENCRYPT) && ((reqOp->type != CRYPTO_OP_TYPE_DECRYPT)))){
      asm volatile ("fence rw,rw" : : : "memory");
      reqOp->state = CRYPTO_OP_STATE_ERROR;
      remove_shared_memory_request(reqOp , sizeOfData);
      continue;
    }
    key_size = reqOp->key_size;
    data_size = reqOp->data_size;
    if ((key_size == 0) || (data_size == 0)){
      asm volatile ("fence rw,rw" : : : "memory");
      reqOp->state = CRYPTO_OP_STATE_ERROR;
      remove_shared_memory_request(reqOp , sizeOfData);
      continue;
    }
    key = reqOp->payload;
    data = reqOp->payload + key_size;
    for(int i = 0; i<data_size; i++){
      data[i] ^= key[i%key_size];
    }
    asm volatile ("fence rw,rw" : : : "memory");
    reqOp->state = CRYPTO_OP_STATE_DONE;
    remove_shared_memory_request(reqOp , sizeOfData);
  }


  exit(0);
}
