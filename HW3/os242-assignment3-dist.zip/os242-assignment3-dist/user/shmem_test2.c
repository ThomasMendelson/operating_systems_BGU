#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
    int parentPid = getpid();
    int childPid;
    char* sharedMem;
    char* pointer = malloc(100*sizeof(char));
    char* privateChildMem;
    if ((childPid = fork()) == 0){
        childPid = getpid();
        printf("child size before map_shared_pages: %d\n",getMemSize());
        //printf("child is printing value before map: %s\n" , pointer);
        sharedMem = map_shared_pages(parentPid, childPid , pointer , 100);
        printf("child size after map_shared_pages: %d\n",getMemSize());
        strcpy (sharedMem , "Hello Daddy");
        unmap_shared_pages(childPid , sharedMem , 100);
        printf("child size after unmap_shared_pages: %d\n",getMemSize());
        privateChildMem = malloc(100*sizeof(char));
        printf("child size after malloc: %d\n",getMemSize());
        strcpy (privateChildMem , "Verifing allocate works properly");
        printf("%s\n",privateChildMem);
        free(privateChildMem);

    }
    else{
        sleep(10);
        printf("parent printing: %s\n" , pointer);
        //printf("parent after writing 'Hello World' to memory\n");
        wait(0);
    }
    free(pointer);
    exit(0);
}